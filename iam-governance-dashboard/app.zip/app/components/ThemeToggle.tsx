// ThemeToggle is no longer needed as we'll use light mode only.
// This file will be maintained as an empty file for now, and can
// be completely removed later if desired. 